// Auto-generated. Do not edit!

// (in-package turtles_server.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class TurtleFollowRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.turtle_name = null;
    }
    else {
      if (initObj.hasOwnProperty('turtle_name')) {
        this.turtle_name = initObj.turtle_name
      }
      else {
        this.turtle_name = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type TurtleFollowRequest
    // Serialize message field [turtle_name]
    bufferOffset = _serializer.string(obj.turtle_name, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type TurtleFollowRequest
    let len;
    let data = new TurtleFollowRequest(null);
    // Deserialize message field [turtle_name]
    data.turtle_name = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.turtle_name);
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'turtles_server/TurtleFollowRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '48e762ec9b058c0b3f8e7717c102b90d';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # TurtleFollow.srv
    
    
    string turtle_name  # İstek kısmı: Takip edilecek kaplumbağanın adı
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new TurtleFollowRequest(null);
    if (msg.turtle_name !== undefined) {
      resolved.turtle_name = msg.turtle_name;
    }
    else {
      resolved.turtle_name = ''
    }

    return resolved;
    }
};

class TurtleFollowResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.response = null;
    }
    else {
      if (initObj.hasOwnProperty('response')) {
        this.response = initObj.response
      }
      else {
        this.response = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type TurtleFollowResponse
    // Serialize message field [response]
    bufferOffset = _serializer.string(obj.response, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type TurtleFollowResponse
    let len;
    let data = new TurtleFollowResponse(null);
    // Deserialize message field [response]
    data.response = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.response);
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'turtles_server/TurtleFollowResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '6de314e2dc76fbff2b6244a6ad70b68d';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string response       # Yanıt kısmı: "OK" mesajı
    
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new TurtleFollowResponse(null);
    if (msg.response !== undefined) {
      resolved.response = msg.response;
    }
    else {
      resolved.response = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: TurtleFollowRequest,
  Response: TurtleFollowResponse,
  md5sum() { return '904f777dcf2c877628dee61e2e2dd4a5'; },
  datatype() { return 'turtles_server/TurtleFollow'; }
};
