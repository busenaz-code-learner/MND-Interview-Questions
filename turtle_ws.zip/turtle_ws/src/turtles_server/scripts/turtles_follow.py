#!/usr/bin/env python3

import rospy
from geometry_msgs.msg import Twist
from turtlesim.msg import Pose
import sys
import tty
import termios
import math
from std_msgs.msg import String
from turtles_server.srv import TurtleFollow, TurtleFollowResponse

# Hız tanımları
LINEAR_SPEED = 2.0
ANGULAR_SPEED = 2.0
FOLLOW_DISTANCE = 1  
MIN_DISTANCE = 0.2     

# PID  Parametreleri
KP_LINEAR = 1.0
KD_LINEAR = 0.05
KI_LINEAR = 0.1
KP_ANGULAR = 4.0
KD_ANGULAR = 0.5
KI_ANGULAR = 0.6

# Klavye yön tuşları 
KEY_BINDINGS = {
    'w': (LINEAR_SPEED, 0),  # İleri
    's': (-LINEAR_SPEED, 0), # Geri
    'a': (0, ANGULAR_SPEED), # Sola dönüş
    'd': (0, -ANGULAR_SPEED) # Sağa dönüş
}

turtle_names = []
leader_name = None
leader_pose = Pose()
turtle_poses = {}


# PID Kontrol
class PIDController:
    def __init__(self, kp, ki, kd):
        self.kp = kp
        self.ki = ki
        self.kd = kd
        self.prev_error = 0.0
        self.integral = 0.0

    def update(self, error, dt):
        # Temel PID hesaplaması
        self.integral += error * dt
        derivative = (error - self.prev_error) / dt if dt > 0 else 0.0
        output = self.kp * error + self.ki * self.integral + self.kd * derivative
        self.prev_error = error
        return output

def get_key():
    tty.setraw(sys.stdin.fileno())
    key = sys.stdin.read(1)
    termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
    return key

def turtle_name_callback(msg):
    turtle_name = msg.data
    if turtle_name not in turtle_names:
        turtle_names.append(turtle_name)

def leader_pose_callback(data):
    global leader_pose
    leader_pose = data

def follower_pose_callback(follower_name):
    def callback(data):
        turtle_poses[follower_name] = data
    return callback

# PID
linear_pid = PIDController(KP_LINEAR, KI_LINEAR, KD_LINEAR)
angular_pid = PIDController(KP_ANGULAR, KI_ANGULAR, KD_ANGULAR)

def move_turtle(follower_name):
    twist = Twist()

    if follower_name in turtle_poses:
        follower_pose = turtle_poses[follower_name]

        # liderin konumu
        dx = leader_pose.x - follower_pose.x
        dy = leader_pose.y - follower_pose.y
        distance = math.sqrt(dx**2 + dy**2)
        
        # mesafe hatası ve PID kullanılarak updatelenmiş lineer hız
        distance_error = distance - FOLLOW_DISTANCE
        dt = 1.0 / 50.0  
        linear_speed = linear_pid.update(distance_error, dt)
        
        
        max_linear_speed = LINEAR_SPEED  
        linear_speed = min(max(linear_speed, -max_linear_speed), max_linear_speed)

        # açı hatasını hesapla 
        angle_to_target = math.atan2(dy, dx)
        angular_error = angle_to_target - follower_pose.theta
        angular_error = math.atan2(math.sin(angular_error), math.cos(angular_error))  #[-pi, pi]

        # PID kullanarak açısal hızını hesapla
        angular_speed = angular_pid.update(angular_error, dt)

        # mesafe kontrolü 
        for other_name, other_pose in turtle_poses.items():
            if other_name != follower_name:
                dx2 = follower_pose.x - other_pose.x
                dy2 = follower_pose.y - other_pose.y
                dist_to_other = math.sqrt(dx2**2 + dy2**2)
                if dist_to_other < MIN_DISTANCE:
                    # Eğer çok yakınlarsa, turtleları ayırmak için hız azalt
                    linear_speed = max(linear_speed - 0.2, 0) 

        # hız limitleri
        twist.linear.x = min(max(linear_speed, -LINEAR_SPEED), LINEAR_SPEED)
        twist.angular.z = max(min(angular_speed, ANGULAR_SPEED), -ANGULAR_SPEED)

        rospy.Publisher(f'/{follower_name}/cmd_vel', Twist, queue_size=10).publish(twist)


def follow_turtle_service(req):
    global leader_name
    if req.turtle_name not in turtle_names:
        return TurtleFollowResponse(response="Turtle not found. Available turtles: " + ", ".join(turtle_names))
    else:
        leader_name = req.turtle_name
        return TurtleFollowResponse(response="OK")

def main():
    global leader_name

    rospy.init_node('turtles_follow')

    rospy.Subscriber('/turtle_names', String, turtle_name_callback)
    rospy.sleep(10)
    print("Oluşturulan kaplumbağalar:", turtle_names)
    leader_name = input("Lider kaplumbağanın adını seçin: ")

    # lider kaplumbağanın pozisyonu
    rospy.Subscriber(f'/{leader_name}/pose', Pose, leader_pose_callback)


    #TurtleFollow servisini başlat
    rospy.Service('turtle_follow_service', TurtleFollow, follow_turtle_service)

    # her bir kaplumbağanın pozisyonu
    for turtle_name in turtle_names:
        rospy.Subscriber(f'/{turtle_name}/pose', Pose, follower_pose_callback(turtle_name))

    rospy.wait_for_service('turtle_follow_service')
    try:
        follow_service = rospy.ServiceProxy('turtle_follow_service', TurtleFollow)
        response = follow_service(turtle_name=leader_name)
        print({response.response})  
    except rospy.ServiceException as e:
        print(f"Servis çağrısı sırasında hata oluştu: {e}")

    print("Lider kaplumbağayı kontrol etmek için yön tuşlarını kullanın (w: ileri, s: geri, a: sola, d: sağa)")
    print("Çıkmak için 'q' tuşuna basın.")


    rate = rospy.Rate(30) 
    while not rospy.is_shutdown():
        key = get_key()
        twist = Twist()

        if key in KEY_BINDINGS:
            twist.linear.x = KEY_BINDINGS[key][0]
            twist.angular.z = KEY_BINDINGS[key][1]
        elif key == 'q':  
            break
        
        #liderin haraket kontrolü
        if leader_name:
            leader_twist = Twist()
            leader_twist.linear.x = KEY_BINDINGS.get(key, (0, 0))[0]
            leader_twist.angular.z = KEY_BINDINGS.get(key, (0, 0))[1]
            rospy.Publisher(f'/{leader_name}/cmd_vel', Twist, queue_size=10).publish(leader_twist)
        
        # Takipçi turtlelar
        for follower_name in turtle_names:
            if follower_name != leader_name:  
                move_turtle(follower_name)
        
        rate.sleep()

if __name__ == "__main__":
    settings = termios.tcgetattr(sys.stdin)
    try:
        main()
    except rospy.ROSInterruptException:
        pass
    finally:
        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
