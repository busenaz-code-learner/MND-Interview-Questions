#!/usr/bin/env python3
import rospy
import random
from turtlesim.srv import Spawn
from std_msgs.msg import String

def spawn_turtles(num_turtles, turtle_name_pub):
    turtle_names = ["turtle1"]  #default olan turtle1'i listeye ekliyoruz
    rospy.sleep(1) 

    # Turtle oluşturma 
    for i in range(2, num_turtles + 1):  # 2. turtle'dan başlat
        x = random.uniform(0, 11)  # harita 11x11
        y = random.uniform(0, 11)
        theta = random.uniform(0, 6.28)  
        turtle_name = "turtle" + str(i)

        rospy.set_param('/turtles/' + turtle_name, {'x': x, 'y': y, 'theta': theta})

        rospy.wait_for_service('spawn')
        try:
            spawn_turtle = rospy.ServiceProxy('spawn', Spawn)
            spawn_turtle(x, y, theta, turtle_name)  # Yeni turtle yaratma
            rospy.loginfo(f"{turtle_name} created at x: {x}, y: {y}, theta: {theta}")

            # turtle isimlerini listeye ekle 
            turtle_names.append(turtle_name)
            
        except rospy.ServiceException as e:
            rospy.logerr("Service call failed: %s" % e)

    # Listeyi sürekli olarak yayınla
    while not rospy.is_shutdown():
        for turtle_name in turtle_names:
            rospy.loginfo(f"Publishing {turtle_name}")
            turtle_name_pub.publish(turtle_name)
            rospy.sleep(2)  # 2 sn Delay

if __name__ == "__main__":
    rospy.init_node('turtles_create')
    
    # Publisher'ı oluştur
    turtle_name_pub = rospy.Publisher('/turtle_names', String, queue_size=50)  

    rospy.sleep(1)  # Delay 

    num_turtles = int(input("Kaç tane kaplumbağa oluşturulsun? "))
    
    spawn_turtles(num_turtles, turtle_name_pub)
